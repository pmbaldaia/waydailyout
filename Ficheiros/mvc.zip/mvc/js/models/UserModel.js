export default class UserModel {
    constructor(id, username, password) {
        this.id = id
        this.username = username
        this.password = password
    }
}