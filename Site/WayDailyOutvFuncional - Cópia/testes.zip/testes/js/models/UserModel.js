export default class UserModel {
    constructor(id, username, password, pontos, type, stade) {
        this.id = id
        this.username = username
        this.password = password
        this.pontos = pontos
        this.type = type
        this.stade = stade
    }
}