import UserController from '../controllers/UserController.js'

export default class AdminView{
    constructor(){
        this.admin = new UserController()
        this.renderTable()

        this.alterarT()
        this.bloquear()
        this.banir()
    }

    renderTable(){
        let utilizadores = this.admin.allUtilizadores()
        let table = document.querySelector('table')
        let resultado = ''
        
        table.innerHTML = `<thead>
                                <tr>
                                    <th>Nome</th>
                                    <th>Passe</th>
                                    <th>Pontos</th>
                                    <th>Tipo</th>
                                    <th>Alterar tipo</th>
                                    <th>Bloquear</th>
                                    <th>Banir</th>
                                </tr>
                            </thead>`
        for (let i = 0; i < utilizadores.length; i++){
            let stade = this.admin.stades(utilizadores[i].username)

            if (stade == 'bloqueado'){
                resultado += `<tr class='table-warning'>`
            }
            else if (stade == 'banido'){
                resultado += `<tr class='table-danger'>`
            }
            else{
                resultado += `<tr>`
            }
            
            resultado += `<td>${utilizadores[i].username}</td>
                          <td>${utilizadores[i].password}</td>
                          <td>${utilizadores[i].pontos}</td>
                          <td>${utilizadores[i].type}</td>
                          <td><button id="${utilizadores[i].username}" class="alterar">Alterar tipo</button></td>
                          <td><button id="${utilizadores[i].username}" class="bloquear">Bloquear</button></td>
                          <td><button id="${utilizadores[i].username}" class="banir">Banir</button></td>
                        </tr>`
        }

        table.innerHTML += resultado
    }

    alterarT(){
        for (const btnAlterar of document.querySelectorAll('.alterar')){
            btnAlterar.addEventListener('click', event => {
                this.admin.alterarTipo(event.target.id)
                this.renderTable()
                location.reload()
            })
        }
    }

    bloquear(){
        for (const btnBloquear of document.querySelectorAll('.bloquear')){
            btnBloquear.addEventListener('click', event => {
                this.admin.bloquearUtilizador(event.target.id)
                this.renderTable()
                location.reload()
            })
        }
    }

    banir(){
        for (const btnBanir of document.querySelectorAll('.banir')){
            btnBanir.addEventListener('click', event => {
                this.admin.banirUtilizador(event.target.id)
                this.renderTable()
                location.reload()
            })
        }
    }
}